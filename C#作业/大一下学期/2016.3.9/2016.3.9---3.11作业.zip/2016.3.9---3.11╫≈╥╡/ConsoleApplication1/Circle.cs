﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Circle:Shape
    {
        public double Radius { get; set; }
        public Circle(double b)
        {
            Radius = b;
        
        }
        public  double GetArea()
        {

            return 3.14 * Radius * Radius;
        
        
        }
        public double GetPerimeter()
        {

            return 2 * Radius * 3.14;
        }



    }
}
