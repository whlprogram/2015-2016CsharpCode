﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {         
            Circle c1 = new Circle(4);
            Circle c2 = new Circle(5);
            Square c3 = new Square(1);
            Square c4 = new Square(2);
            Shape[] a = new Shape[4];
            a[0] = c1; 
            a[1] = c2;
            a[2] = c3;
            a[3] = c4;
            foreach (var m in a)
            {
                if (m is Square)
                {
                    Square m = (Square ) i;
                    Console.WriteLine(i.GetPerimeter());
                }
                else
                    Console.WriteLine(m.GetArea());
            }

        }
    }
}
