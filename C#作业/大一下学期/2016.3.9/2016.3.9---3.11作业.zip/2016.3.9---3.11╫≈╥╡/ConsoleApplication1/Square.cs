﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Square :  Shape
    {
        public double x { get; set; }
        public Square(double c)
        {
            x = c;
        }
        public  double GetArea()
        {


            return x * x;


        }
       public  double GetPerimeter()
        {

            return 4 * x;
        }


    }
}
