﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication300000
{
    class Program
    {
        private static Random randomNumbers = new Random();
        private enum Status { CONTINUE, WON, LOST }
        private enum DiceNames
        {
            SNAKE_EYES = 2,
            TREY = 3,
            SEVEN = 7,
            YO_LEVEN = 11,
            BOX_CARS = 12
        }
        static void Main(string[] args)
        {
            int balance = 1000;
            Console.WriteLine("请输入下注额，不得大于本金");
            int wager = Convert.ToInt32(Console .ReadLine ());
            while  (wager  > 1000)
            {
                int newwager = Convert.ToInt32(Console.ReadLine());
                wager  = newwager ;
            }
            

            Status gameStatus = Status.CONTINUE;
            int myPoint = 0;

            int sumOfDice = RollDice();
            switch ((DiceNames)sumOfDice)
            {
                case DiceNames.SEVEN:
                case DiceNames.YO_LEVEN:
                    gameStatus = Status.WON;
                    balance += wager;
                    break;
                case DiceNames.SNAKE_EYES:
                case DiceNames.TREY:
                case DiceNames.BOX_CARS:
                    gameStatus = Status.LOST;
                    balance = balance - wager;
                    break;
                default:
                    balance = 1000;
                    gameStatus = Status.CONTINUE;
                    myPoint = sumOfDice;
                    Console.WriteLine("Point is {0}", myPoint);
                    break;
            }
            while (gameStatus == Status.CONTINUE)
            {
                sumOfDice = RollDice();
                if (sumOfDice == myPoint)
                {
                    gameStatus = Status.WON;
                    balance += wager;
                }
                else
                    if (sumOfDice == (int)DiceNames.SEVEN)
                    {
                        gameStatus = Status.LOST;
                        balance = balance - wager;
                    }
            }
            if (gameStatus == Status.WON)
                Console.WriteLine("Player wins");
            else
                Console.WriteLine("Player loses");
            Console.WriteLine("余额:{0}",balance);

        }
        public static int RollDice()
        {
            int die1 = randomNumbers.Next(1, 7);
            int die2 = randomNumbers.Next(1, 7);
            int sum = die1 + die2;
            Console.WriteLine("Player rolled {0}+{1}={2}", die1, die2, sum);
            return sum;
        }
    }
}
