﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Class1
    {
        Random face = new Random();
        public void F1()  //P180页7.10案例研究
        {

            int sum = 0;
            int sum1 = F2(sum);
            Console.WriteLine("第一次点数和为：{0}", sum1);
            switch (sum1)
            {
                case 7:
                case 11:
                    Console.WriteLine("玩家赢");
                    break;
                case 2:
                case 3:
                case 12:
                    Console.WriteLine("庄家赢");
                    break;
                default:
                    Console.WriteLine("玩家继续掷骰子");

                    int sum2 = 0;

                    while ((sum2 != sum1) && (sum2 != 7))
                    {
                        int Face1 = face.Next(1, 7);
                        int Face2 = face.Next(1, 7);
                        sum2 = Face1 + Face2;
                        Console.WriteLine(sum2);

                    }
                    if (sum2 == sum1)
                        Console.WriteLine("玩家赢");
                    else
                        Console.WriteLine("庄家赢");
                    break;
            }

        }

        public int F2(int z)
        {


            int face1, face2;
            face1 = face.Next(1, 7);
            face2 = face.Next(1, 7);
            z = face1 + face2;
            return z;
        }




        public void F3() //P204页7.30
        {
            Random a = new Random();
            int b = a.Next(1, 1001);
            Console.WriteLine(b);
            Console.WriteLine("Guess a number between 1 and 1000");
            int c = Convert.ToInt32(Console.ReadLine());

            while (c != b)
            {
                if (c > b)
                {
                    Console.WriteLine("Too high.Try again");
                    int C1 = Convert.ToInt32(Console.ReadLine());
                    c = C1;
                }
                if (c < b)
                {
                    Console.WriteLine("Too low.Try again");
                    int C2 = Convert.ToInt32(Console.ReadLine());
                    c = C2;
                }
            }

            if (c == b)
                Console.WriteLine("Congratulations.You guessed the number!");

            Console.WriteLine("Do you want to try again? Return 'yes'or'no'");
            string R = Console.ReadLine();
            if (R == "yes")
                F3();
        }



        public int F4() //P204页7.31
        {
            int i = 0;
            {
                Random a = new Random();
                int b = a.Next(1, 1001);
                Console.WriteLine(b);
                Console.WriteLine("Guess a number between 1 and 1000");
                int c = Convert.ToInt32(Console.ReadLine());
                ++i;

                while (c != b)
                {
                    if (c > b)
                    {
                        Console.WriteLine("Too high.Try again");
                        int C1 = Convert.ToInt32(Console.ReadLine());
                        ++i;
                        c = C1;
                    }
                    if (c < b)
                    {
                        Console.WriteLine("Too low.Try again");
                        int C2 = Convert.ToInt32(Console.ReadLine());
                        ++i;
                        c = C2;
                    }
                }
                if (c == b)
                    Console.WriteLine("Congratulations.You guessed the number!");
                Console.WriteLine("i={0}", i);

                Console.WriteLine("Do you want to try again? Return 'yes'or'no'");
                string R = Console.ReadLine();
                if (R == "yes")
                    F4();
                return i;
            }
        }
        public void F5()
        {

            int I = F4();
            if (I < 10)
                Console.WriteLine("Either you know the secret or you got lucky!");
            else if (I > 10)
                Console.WriteLine("You should be able to do better");
            else if (I == 10)
                Console.WriteLine("Aha!You know the secret!");
        }
    }
}
